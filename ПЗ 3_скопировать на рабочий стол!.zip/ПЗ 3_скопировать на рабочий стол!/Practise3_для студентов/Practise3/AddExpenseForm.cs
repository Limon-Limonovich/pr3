﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practise3
{
    public partial class AddExpenseForm : Form
    {
        public Expense NewExpense { get; private set; }

        public AddExpenseForm()
        {
            InitializeComponent();
            dtpDate.Value = DateTime.Today;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                NewExpense = new Expense
                {
                    Date = dtpDate.Value,
                    Description = txtDescription.Text.Trim(),
                    Amount = decimal.Parse(txtAmount.Text),
                    ReceiptNumber = txtReceiptNumber.Text.Trim()
                };

                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Введите описание расхода");
                return false;
            }

            return true;
        }
    }
}