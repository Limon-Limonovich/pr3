﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practise3
{
    public static class ExpenseData
    {
        private static readonly string DataFile = "expenses.txt";

        public static List<Expense> LoadExpenses()
        {
            var expenses = new List<Expense>();

            if (File.Exists(DataFile))
            {
                var lines = File.ReadAllLines(DataFile);
                foreach (var line in lines)
                {
                    var parts = line.Split('|');
                    if (parts.Length == 4)
                    {
                        expenses.Add(new Expense
                        {
                            Date = DateTime.ParseExact(parts[0], "yyyyMMdd", null),
                            Description = parts[1],
                            Amount = decimal.Parse(parts[2]),
                            ReceiptNumber = parts[3]
                        });
                    }
                }
            }

            return expenses.OrderByDescending(e => e.Date).ToList();
        }

        public static void SaveExpense(Expense expense)
        {
            try
            {
                var line = $"{expense.Date}|{expense.Description}|{expense.Amount}|{expense.ReceiptNumber}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения данных: {ex.Message}");
            }
        }
    }
}
