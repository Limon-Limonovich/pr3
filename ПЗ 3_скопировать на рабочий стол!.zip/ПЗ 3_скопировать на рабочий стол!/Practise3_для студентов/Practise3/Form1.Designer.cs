﻿
namespace Practise3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "Form1";

            this.expenseGridView = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.expenseGridView)).BeginInit();
            this.SuspendLayout();

            // expenseGridView
            this.expenseGridView.AllowUserToAddRows = false;
            this.expenseGridView.AllowUserToDeleteRows = false;
            this.expenseGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.expenseGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.expenseGridView.Location = new System.Drawing.Point(0, 0);
            this.expenseGridView.Name = "expenseGridView";
            this.expenseGridView.ReadOnly = true;
            this.expenseGridView.Size = new System.Drawing.Size(800, 400);
            this.expenseGridView.TabIndex = 0;

            // btnAdd
            this.btnAdd.Location = new System.Drawing.Point(12, 415);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(150, 35);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Добавить чек";
            this.btnAdd.UseVisualStyleBackColor = true;

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 462);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.expenseGridView);
            this.Name = "MainForm";
            this.Text = "Контроль расходов";
            ((System.ComponentModel.ISupportInitialize)(this.expenseGridView)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView expenseGridView;
        private System.Windows.Forms.Button btnAdd;
    }

    #endregion
}

