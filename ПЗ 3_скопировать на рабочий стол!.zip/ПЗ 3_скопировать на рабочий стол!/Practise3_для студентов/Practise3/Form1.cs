﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practise3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            LoadExpenses();
        }

        private void LoadExpenses()
        {
            expenseGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Настройка форматирования колонок
            expenseGridView.Columns["Date"].DefaultCellStyle.Format = "dd.MM.yyyy";
            expenseGridView.Columns["Amount"].DefaultCellStyle.Format = "F0";
            expenseGridView.Columns["Amount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var addForm = new AddExpenseForm();
            LoadExpenses();
        }
    }
}